#include <stdio.h>
#include <stdlib.h>
/*
3.	Escreva uma fun��o mm que receba um vetor inteiro v[0..n-1] 
e os endere�os de duas vari�veis inteiras, digamos media e soma, 
e deposite nessas vari�veis o valor da m�dia e o valor da soma do vetor. 
Escreva tamb�m uma fun��o main que use a fun��o mm. 
*/
void mm(int * vet, int * media, int * soma);
int main(int argc, char *argv[]) {		
	int * vet, i, soma=0, media;
	vet = malloc(10*sizeof(int));
	for(i=0;i<10;i++){
		printf("Informe valor: ");
		scanf("%d", vet+i);
	}
	mm(vet, &media, &soma);
	printf("Soma: %d", soma);
	printf("Media: %d", media);
	return 0;
}

void mm(int * vet, int * media, int * soma){
	int i;
	for(i=0;i<10;i++){
		*soma = *soma + *(vet+i);
	}
	*media = *soma / 10;
	
}

