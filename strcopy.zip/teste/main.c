#include <stdio.h>
#include <stdlib.h>
/*
Crie uma fun��o que receba uma string como par�metro 
(de tamanho desconhecido) e retorne uma c�pia da mesma. 
A assinatura da fun��o deve  ser:

char *strcopy(char *str);

*/
char *strcopy(char *str);
int main(int argc, char *argv[]) {		
	int tam;
	char nome[30], *nome2;
	printf("Digite nome: ");
	scanf("%s", &nome);
	nome2 = strcopy(nome);
	printf("Copia: %c  ", nome2[1]);
	
	return 0;
}

char * strcopy(char *str){
	int tam,i;
	char * str_cpy;
	for(tam=0; str[tam] != '\0'; tam++){}
	str_cpy = malloc(tam*sizeof(char));
	for(i=0; i<=tam; i++){
		str_cpy[i] = str[i];		
	}
	return str_cpy;
}
