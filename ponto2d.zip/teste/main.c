#include <stdio.h>
#include <stdlib.h>
/*
Construa um struct chamado ponto2d que tenha como atributos os pontos 
x e y, depois crie duas vari�veis do tipo ponto2d chamadas 
ponto_inicial e ponto_final. 
Utilize a fun��o informa_ponto(struct ponto2d *p) para armazenar 
os valores das vari�veis x e y.

Fa�a um menu com as seguintes op��es e implemente?as:
[1] - Digitar o valor do ponto x
[2] - Digitar o valor do ponto y
[3] - Mostrar a dist�ncia entre os pontos
[4] - Sair
DICA: Dist�ncia entre dois pontos (x1,y1)(x2,y2): 
raiz quadrada de (x1-x2)�+(y1-y2)�
*/

struct ponto2d{
	int x, y;
};

void informa_ponto(struct ponto2d *p);
int total;
int main(int argc, char *argv[]) {		
	struct ponto2d ponto_inicial, ponto_final;
	int opcao;
	
	do{
		system("cls");
		printf("\n[1] - Digitar o valor do ponto x");
		printf("\n[2] - Digitar o valor do ponto y");
		printf("\n[3] - Mostrar a dist�ncia entre os pontos");
		printf("\n[4] - Sair\n");
		printf("\nOpcao: ");
		scanf("%d", &opcao);
		switch(opcao){
			case 1: informa_ponto(&ponto_inicial);
					break; 
			case 2: informa_ponto(&ponto_final);
					break;
			case 3: total = sqrt((ponto_inicial.x-ponto_final.x)*(
							ponto_inicial.x-ponto_final.x))+
							((ponto_inicial.y-ponto_final.y)*
							(ponto_inicial.y-ponto_final.y));
					printf("Total %d", total);
					getch(); 
					break;
			case 4: printf("Saindo!"); 
					getch(); 
					break;
			default: printf("Opcao Invalida!");
		}
		
	}while(opcao!=4);
	
	return 0;
}

void informa_ponto(struct ponto2d *p){
	printf("Informe o ponto X: ");
	scanf("%d", &p->x);
	printf("Informe o ponto Y: ");
	scanf("%d", &p->y);
}

