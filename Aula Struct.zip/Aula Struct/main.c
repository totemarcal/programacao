#include <stdio.h>
#include <stdlib.h>
#include<math.h>

struct pessoa{
       int idade;
       char nome[30];
       } typedef Pessoa;

int main(int argc, char *argv[])
{
    int i;
    struct pessoa funcionario[3];
    printf("A raiz quadrada de 4 eh: %2.f", sqrt(4));
    
    for(i=0; i<3; i++){
        printf("Digite o nome:");    
        gets(funcionario[i].nome);
        printf("Digite a idade:");
        scanf("%i",&funcionario[i].idade);
        fflush(stdin);
    }
    for(i=0; i<3; i++){    
        printf("O nome eh: %s \n", funcionario[i].nome);
        printf("A idade eh: %i \n", funcionario[i].idade);
    }
    
    getch();
  return 0;
}
